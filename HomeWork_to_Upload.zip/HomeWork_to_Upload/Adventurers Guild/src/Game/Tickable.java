package Game;

/**
 * @author bened
 * If you need something to tick
 */
public interface Tickable {
	public void Tick();
}
